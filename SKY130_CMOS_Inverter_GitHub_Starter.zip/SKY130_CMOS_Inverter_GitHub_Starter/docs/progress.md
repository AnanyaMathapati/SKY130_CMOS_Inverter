# Project progress log

Last updated: 24 November 2026

## Completed / observed

- [x] Ubuntu/WSL development environment used.
- [x] SKY130A PDK configured and loaded in Magic.
- [x] Xschem schematic, inverter symbol and testbench files created.
- [x] Xschem-generated SPICE netlist inspected for transistor connectivity.
- [x] Transient simulation run earlier; inverter-like output transition observed.
- [x] Magic top-level cell contains the NMOS and PMOS device instances.
- [x] A pre-routing backup of `cmos_inverter.mag` was created during debugging.

## In progress

- [ ] Confirm current schematic W/L/nf values from the latest generated netlist.
- [ ] Complete and verify the physical connections for IN, OUT, VDD and VSS.
- [ ] Verify well/substrate taps and body connections.
- [ ] Capture a clean full-layout screenshot from the user's own Magic session.

## Not yet verified

- [ ] DRC-clean layout.
- [ ] Extracted layout netlist electrically equivalent to the schematic.
- [ ] Netgen LVS match.

## Important working notes

- Use the local Magic build at `~/opt/magic-8.3.703/bin/magic`, not the older system Magic, unless the environment is intentionally changed.
- Use the local Netgen build at `~/opt/netgen-1.5.332/bin/netgen`; `/usr/bin/netgen` was identified as an unrelated Ubuntu package.
- Do not treat a displayed DRC tile count by itself as proof of a clean DRC run.
- Preserve the working schematic and symbol. Make a backup before modifying the layout.
