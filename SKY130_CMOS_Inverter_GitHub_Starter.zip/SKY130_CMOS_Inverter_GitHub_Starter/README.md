# SKY130 CMOS Inverter Design Using Xschem and Magic

A hands-on custom IC design project to implement a CMOS inverter using the SkyWater SKY130A process design kit (PDK). The project workspace contains the Xschem schematic and testbench, SPICE netlists, and the beginning of a Magic physical-layout flow.

> **Progress note (24 November 2026):** The schematic/testbench work and initial Magic device placement have been completed. The physical interconnect is still in progress. DRC-clean status and LVS matching have **not** yet been demonstrated. This README deliberately records the current state rather than claiming unfinished verification results.

## Project objectives

- Create a CMOS inverter schematic using SKY130A NMOS and PMOS devices.
- Create a reusable inverter symbol and use it in a testbench.
- Generate a SPICE netlist from Xschem.
- Run transient simulation and inspect the inverter response.
- Create the physical layout in Magic using SKY130A.
- Extract a layout netlist, run DRC, and compare schematic and layout using Netgen LVS.

## Tools and technology

The project was developed in an Ubuntu environment (WSL on Windows).

| Tool / technology | Role | Environment recorded |
|---|---|---|
| Ubuntu / WSL | Linux development environment | Used |
| Xschem | Schematic capture and SPICE netlisting | Local build under `~/opt/xschem-3.4.7/` (reported version output: V3.4.8RC); system package also present |
| Magic | Physical layout, DRC and extraction | Local build `8.3.703`; executable `~/opt/magic-8.3.703/bin/magic` |
| Netgen | Layout-versus-schematic comparison | Local build `1.5.332`; executable `~/opt/netgen-1.5.332/bin/netgen` |
| ngspice | SPICE simulation | Version `45.2` |
| SkyWater SKY130A PDK | Device definitions, technology and design rules | Located at `/usr/local/share/pdk/sky130A/` |

The PDK is an external dependency and is not included in this repository. Tool paths and versions describe the development machine and may need adjustment on another computer.

## Design overview

A CMOS inverter uses a PMOS pull-up device and an NMOS pull-down device. Their gates share the input. Their drains are intended to form the output. The PMOS source/body connect to VDD; the NMOS source/body connect to VSS.

| Device terminal | Intended connection |
|---|---|
| PMOS gate | IN |
| PMOS source | VDD |
| PMOS bulk | VDD |
| PMOS drain | OUT |
| NMOS gate | IN |
| NMOS source | VSS |
| NMOS bulk | VSS |
| NMOS drain | OUT |

The Xschem-generated netlist previously inspected showed the following device parameters and terminal order:

- NMOS: `L=0.18`, `W=4.5`, `nf=1`
- PMOS: `L=0.18`, `W=3`, `nf=1`

These are the last values captured in the project notes. If the schematic has since been edited, regenerate its netlist and update this section to match the current file.

## Repository structure

```text
SKY130_CMOS_Inverter/
├── README.md
├── .gitignore
├── docs/
│   └── progress.md
├── xschem/
│   └── (copy the project .sch and .sym files here)
├── mag/
│   └── (copy the project .mag and generated extraction/netlist files here)
├── simulation/
│   └── results/
└── screenshots/
    └── (add screenshots captured from your own project)
```

## Design flow and current progress

### 1. Environment and tool availability

The following tools and PDK were located and used during setup:

- Magic: `/home/anany/opt/magic-8.3.703/bin/magic`
- Netgen: `/home/anany/opt/netgen-1.5.332/bin/netgen`
- Xschem: `~/opt/xschem-3.4.7/bin/xschem`
- SKY130A PDK: `/usr/local/share/pdk/sky130A/`
- Project workspace: `~/VSD_CMOS_Inverter/`

Magic was launched with the SKY130A technology configuration through the project's `.magicrc` setup.

### 2. Schematic capture in Xschem

The project includes:

- `cmos_inverter.sch` — CMOS inverter schematic
- `cmos_inverter.sym` — reusable inverter symbol
- `cmos_inv_tb.sch` — inverter testbench

The generated SPICE netlist was inspected. It showed the intended transistor topology:

```spice
XM1 OUT IN vss vss sky130_fd_pr__nfet_01v8 L=0.18 W=4.5 nf=1
XM2 OUT IN vdd vdd sky130_fd_pr__pfet_01v8 L=0.18 W=3 nf=1
```

The exact generated file may include additional model parameters and simulator directives. The snippet above records the terminal connectivity and key dimensions captured during the project.

### 3. Testbench and simulation

A testbench was created and a transient response was run earlier in the workflow. The observed output transitioned in the opposite direction to the input, consistent with inverter operation.

Add the actual Xschem/ngspice waveform screenshot and simulation log under `screenshots/` and `simulation/results/` before publishing. Do not add screenshots from another person's repository as evidence of this project's result.

### 4. Physical layout in Magic

Magic was launched with the SKY130A technology. Two generated device cells were placed in the top-level `cmos_inverter` cell:

- NMOS instance: `XM1` (`sky130_fd_pr__nfet_01v8_4CL9BQ`)
- PMOS instance: `XM2` (`sky130_fd_pr__pfet_01v8_UC2RFG`)

The two devices were arranged vertically, with the PMOS above the NMOS. At the last recorded checkpoint, the layout contained the device instances but did not yet contain verified complete routing for IN, OUT, VDD and VSS.

The layout and extracted files are works in progress. Keep a backup before further edits.

### 5. DRC and LVS — pending

The following steps remain:

1. Complete the physical interconnect for IN, OUT, VDD and VSS.
2. Add/verify the required well and substrate taps and device body connections.
3. Run the SKY130A DRC checks and resolve all reported violations.
4. Extract the layout netlist from Magic.
5. Compare the schematic and extracted layout netlists using the correct local Netgen LVS executable.
6. Save the final DRC and LVS reports and screenshots.

**Current verification status:** DRC clean — not yet confirmed. LVS match — not yet confirmed.

## Files to add from the working project

Copy the actual project files from `~/VSD_CMOS_Inverter/` into the matching folders:

| Source file | Repository destination |
|---|---|
| `xschem/cmos_inverter.sch` | `xschem/cmos_inverter.sch` |
| `xschem/cmos_inverter.sym` | `xschem/cmos_inverter.sym` |
| `xschem/cmos_inv_tb.sch` | `xschem/cmos_inv_tb.sch` |
| `mag/cmos_inverter.mag` | `mag/cmos_inverter.mag` |
| `mag/cmos_inverter.spice` | `mag/cmos_inverter.spice` |
| `mag/cmos_inverter.ext` | `mag/cmos_inverter.ext` |
| Generated device `.mag` files required by the top-level layout | `mag/` |

Only include files that exist and are needed. Do not commit temporary backups, unrelated generated cells, or PDK source files.

## Reproducing the project environment

Example commands for the current machine (adjust paths if your installation differs):

```bash
export PDK_ROOT=/usr/local/share/pdk
export PDK=sky130A

cd ~/VSD_CMOS_Inverter/xschem
~/opt/xschem-3.4.7/bin/xschem \
  --rcfile /usr/local/share/pdk/sky130A/libs.tech/xschem/xschemrc \
  cmos_inverter.sch
```

Launch Magic from the layout folder:

```bash
cd ~/VSD_CMOS_Inverter/mag
~/opt/magic-8.3.703/bin/magic -d XR
```

Use the local Netgen build for LVS work:

```bash
~/opt/netgen-1.5.332/bin/netgen
```

The final LVS command depends on the exact schematic and extracted netlist filenames and the setup file used for SKY130A; record the verified command and report after the comparison has actually run.

## Author

Ananya Mathapati

## License

No license has been selected yet. Add a license file before presenting this repository as open source.
